package com.tony.admindashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdmindashboardApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdmindashboardApplication.class, args);
	}
}
